from UniversalNumbers import _parse_input_type
from unum import Unum


def convert(input) -> Unum:
    return _parse_input_type(input)
